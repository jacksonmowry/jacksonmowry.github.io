#ifndef RTWEEKEND_H_
#define RTWEEKEND_H_

double degrees_to_radians(double degrees);

double random_double(void);

double random_double_min_max(double min, double max);

#endif // RTWEEKEND_H_
