# Running code
- sha1.c outputs the required 5 lines of message digests for part 1, just compile using your favorite C compiler and run the output
- bad_sha1.c outputs the newly created bad message, along with the new MAC, again compile using a C compiler and run
- Neither program takes any arguments
