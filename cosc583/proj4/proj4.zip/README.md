# Running code
C code is compiled as such

``` shell
gcc -lcrypto -lm rsa.c -o rsa
gcc -lcrypto -lm diffie.c -o diffie
```

Python code just runs, and uses hard coded values from my results and the pass-off server
