1. Include a README file that includes the following:
    - How to compile and run your code
      - Code can be run by using `bash main.bash`, tested to work on bash version 5.3.3
      - Output is printed, can be compared to the appendix_c.txt file, or your own version of the appendix
    - A statement about whether you looked at only the resources listed above or whether you used additional material
      - I only looked at the material provided on the project writeup page
    - A statement about which test cases in Appendix C you pass or fail
      - I pass all test cases in Appendix C
