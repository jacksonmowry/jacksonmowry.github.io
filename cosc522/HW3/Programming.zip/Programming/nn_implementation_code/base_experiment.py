from collections import Counter

import numpy as np
import seaborn as sns
import torch
import torchvision
import torchvision.transforms as transforms
from matplotlib import pyplot as plt
from tqdm import tqdm

from custom_modules import Linear, CrossEntropyLoss, Sigmoid


if __name__ == "__main__":
    trainset = torchvision.datasets.FashionMNIST(root='./data', train=True,
                                                 download=True, transform=transforms.ToTensor())

    testset = torchvision.datasets.FashionMNIST(root='./data', train=False,
                                                download=True, transform=transforms.ToTensor())

    weights = torch.load("weights.pt")
    print(weights)
